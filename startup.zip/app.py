from flask import Flask, render_template, request
import requests
import os

app = Flask(__name__)


SUBSCRIPTION_KEY = os.environ.get("CV_KEY", "40B4q49qZD7ggKLX2mbv2lOaquj3m371LmHvF6fGdZQ0BaMQXOhdJQQJ99BLAC5T7U2XJ3w3AAAFACOG8PGC" )
#SUBSCRIPTION_KEY = os.environ.get("CV_KEY")

ENDPOINT = os.environ.get("CV_ENDPOINT", "https://cv-sports.cognitiveservices.azure.com/" )
#ENDPOINT = os.environ.get("CV_ENDPOINT")

ANALYZE_URL = ENDPOINT.rstrip("/") + "/vision/v3.2/analyze"



def predict_sport_from_tags(tags):
    SPORT_KEYWORDS = {
        "Football": ["soccer", "football", "football player", "soccer ball"],
        "Basketball": ["basketball", "basketball player", "basketball court"],
        "Tennis": ["tennis", "tennis racket", "tennis court"],
        "Swimming": ["swimming", "swimmer", "swimming pool"],
        "Athletics": ["running", "runner", "track", "athletics"],
    }
    scores = {sport: 0.0 for sport in SPORT_KEYWORDS}
    for tag in tags:
        name = tag["name"].lower()
        conf = tag.get("confidence", 0.0)
        for sport, keywords in SPORT_KEYWORDS.items():
            if name in keywords:
                scores[sport] = max(scores[sport], conf)
    best_sport = max(scores, key=scores.get)
    return best_sport, scores[best_sport], scores

@app.route("/", methods=["GET", "POST"])
def index():
    prediction = None
    score = None
    if request.method == "POST":
        image_url = request.form.get("image_url")

        params = {"visualFeatures": "Tags,Description,Objects", "language": "en"}
        headers = {
            "Ocp-Apim-Subscription-Key": SUBSCRIPTION_KEY,
            "Content-Type": "application/json"
        }
        data = {"url": image_url}

        response = requests.post(ANALYZE_URL, headers=headers, params=params, json=data)
        response.raise_for_status()
        result = response.json()

        tags = result.get("tags", [])
        prediction, score, all_scores = predict_sport_from_tags(tags)

    return render_template("index.html", prediction=prediction, score=score)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080, debug=True)
